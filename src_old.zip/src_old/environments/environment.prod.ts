export const environment = {
  production: true,
  basePath: '/mobile/#/',
  dasboardPath: '/mobile/#/home',
  projectPath : '/mobile/#/login',
  apiUrl : 'http://3.138.109.91:5000/api/',
  rzp_key_id: 'rzp_test_3y2EfpyvWXWhg3',
  rzp_key_secret: 'WH3KAIawNotIN7fhYCrtcZdp',
  hosted_api_url: 'http://cp-33.hostgator.tempwebhost.net/~a1627unp/wevouch/',
};
