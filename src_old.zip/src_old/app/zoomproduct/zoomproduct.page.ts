import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zoomproduct',
  templateUrl: './zoomproduct.page.html',
  styleUrls: ['./zoomproduct.page.scss'],
})
export class ZoomproductPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
