import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addproductpage2',
  templateUrl: './addproductpage2.page.html',
  styleUrls: ['./addproductpage2.page.scss'],
})
export class Addproductpage2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
