import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addproductpage3',
  templateUrl: './addproductpage3.page.html',
  styleUrls: ['./addproductpage3.page.scss'],
})
export class Addproductpage3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
